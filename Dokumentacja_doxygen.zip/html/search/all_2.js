var searchData=
[
  ['delete',['Delete',['../class_web_application1_1_1_controllers_1_1_trains_controller.html#a98d2c4ecb482369d58632b477db34ec0',1,'WebApplication1::Controllers::TrainsController']]],
  ['deleteconfirmed',['DeleteConfirmed',['../class_web_application1_1_1_controllers_1_1_trains_controller.html#a1241f1f102197e17b6411f4271eccd4d',1,'WebApplication1::Controllers::TrainsController']]]
];
