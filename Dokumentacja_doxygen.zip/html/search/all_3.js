var searchData=
[
  ['edit',['Edit',['../class_web_application1_1_1_controllers_1_1_trains_controller.html#a9492a995fe3d21dc9d33f82de9a81068',1,'WebApplication1::Controllers::TrainsController']]]
];
